'use client'
import { useState } from 'react'
import {
  LayoutDashboard, Star, Building2, AlertTriangle,
  TrendingUp, Bell, Settings, ChevronLeft, ChevronRight,
  Users, BarChart3
} from 'lucide-react'
import { cn } from '@/lib/utils'

const NAV = [
  { href: '#overview', icon: LayoutDashboard, label: 'Обзор' },
  { href: '#reviews', icon: Star, label: 'Отзывы' },
  { href: '#branches', icon: Building2, label: 'Филиалы' },
  { href: '#alerts', icon: AlertTriangle, label: 'Алерты', badge: 3 },
  { href: '#analytics', icon: BarChart3, label: 'Аналитика' },
  { href: '#competitors', icon: TrendingUp, label: 'Конкуренты' },
  { href: '#team', icon: Users, label: 'Команда' },
  { href: '#settings', icon: Settings, label: 'Настройки' },
]

const BRAND_TEAL = '#3A9EA5'
const BRAND_ORANGE = '#F5813F'

function SadykhanLogo({ size = 36 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="18" cy="18" r="17" stroke={BRAND_TEAL} strokeWidth="2" fill="white"/>
      <path d="M7 22 Q12 11 18 15.5 Q22 19 29 12" stroke={BRAND_ORANGE} strokeWidth="3.2" strokeLinecap="round" fill="none"/>
      <path d="M8 26 Q13 15 19 19.5 Q23 23 30 16" stroke={BRAND_ORANGE} strokeWidth="2" strokeLinecap="round" fill="none" opacity="0.55"/>
    </svg>
  )
}

interface Props { active: string; onNav: (id: string) => void }

export default function Sidebar({ active, onNav }: Props) {
  const [collapsed, setCollapsed] = useState(false)

  return (
    <aside className={cn(
      'flex flex-col bg-white border-r border-gray-100 transition-all duration-200 shrink-0',
      collapsed ? 'w-14' : 'w-56'
    )}>
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-3 py-4 border-b border-gray-100">
        <div className="shrink-0">
          <SadykhanLogo size={collapsed ? 28 : 36} />
        </div>
        {!collapsed && (
          <div>
            <div className="leading-tight font-semibold text-base" style={{ color: BRAND_TEAL, letterSpacing: '-0.3px' }}>
              садыхан
            </div>
            <div className="text-[10px] text-gray-400 leading-tight">Репутация 2GIS</div>
          </div>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 py-3 px-2 space-y-0.5 overflow-y-auto">
        {NAV.map((item) => {
          const Icon = item.icon
          const isActive = active === item.href.slice(1)
          return (
            <button
              key={item.href}
              onClick={() => onNav(item.href.slice(1))}
              className={cn(
                'w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-left transition-colors text-sm',
                isActive ? 'text-white' : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'
              )}
              style={isActive ? { background: BRAND_TEAL } : {}}
            >
              <Icon className="w-4 h-4 shrink-0" />
              {!collapsed && (
                <span className="flex-1 text-sm">{item.label}</span>
              )}
              {!collapsed && item.badge && (
                <span className="text-[10px] px-1.5 py-0.5 rounded-full text-white font-medium"
                  style={{ background: BRAND_ORANGE }}>
                  {item.badge}
                </span>
              )}
            </button>
          )
        })}
      </nav>

      {/* Collapse toggle */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="m-2 p-1.5 rounded-lg text-gray-400 hover:bg-gray-50 hover:text-gray-700 transition-colors flex items-center justify-center"
      >
        {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
      </button>
    </aside>
  )
}
