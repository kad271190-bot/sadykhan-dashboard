'use client'
import { useState } from 'react'
import {
  LayoutDashboard, Star, Building2, AlertTriangle,
  TrendingUp, Settings, ChevronLeft, ChevronRight,
  Users, BarChart3, MessageSquare, ThumbsUp
} from 'lucide-react'
import { cn } from '@/lib/utils'

const NAV = [
  { href: '#overview', icon: LayoutDashboard, label: 'Обзор' },
  { href: '#reviews', icon: Star, label: 'Отзывы' },
  { href: '#replies', icon: MessageSquare, label: 'Ответы', badge: 4 },
  { href: '#branches', icon: Building2, label: 'Филиалы' },
  { href: '#alerts', icon: AlertTriangle, label: 'Алерты', badge: 3 },
  { href: '#analytics', icon: BarChart3, label: 'Аналитика' },
  { href: '#nps', icon: ThumbsUp, label: 'NPS' },
  { href: '#competitors', icon: TrendingUp, label: 'Конкуренты' },
  { href: '#settings', icon: Settings, label: 'Настройки' },
]

// Sadykhan logo — точная копия оригинала
function SadykhanLogo({ size = 34 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 34 34" fill="none">
      {/* Бирюзовый незамкнутый круг (как буква С) */}
      <path
        d="M30 17 A13 13 0 1 1 24 6.5"
        stroke="#3A9EA5" strokeWidth="3.5" fill="none"
        strokeLinecap="round"
      />
      {/* Оранжевые три полосы внутри */}
      <path d="M11 20 Q17 14 26 16" stroke="#F5813F" strokeWidth="2.8" strokeLinecap="round" fill="none"/>
      <path d="M12 23.5 Q18 17.5 27 19.5" stroke="#F5813F" strokeWidth="2.2" strokeLinecap="round" fill="none" opacity="0.85"/>
      <path d="M13.5 27 Q19.5 21 28 23" stroke="#F5813F" strokeWidth="1.6" strokeLinecap="round" fill="none" opacity="0.6"/>
    </svg>
  )
}

// 2GIS логотип
function TwoGisIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
      <rect width="32" height="32" rx="7" fill="#1DB954" opacity="0"/>
      <rect width="32" height="32" rx="7" fill="url(#twogis-bg)"/>
      <defs>
        <linearGradient id="twogis-bg" x1="0" y1="0" x2="32" y2="32">
          <stop offset="0%" stopColor="#F5A623"/>
          <stop offset="50%" stopColor="#27AE60"/>
          <stop offset="100%" stopColor="#1A8A3C"/>
        </linearGradient>
      </defs>
      {/* map pin */}
      <circle cx="16" cy="13" r="5" fill="#2196F3"/>
      <path d="M16 18 L16 24" stroke="#2196F3" strokeWidth="3" strokeLinecap="round"/>
      <circle cx="16" cy="13" r="2.5" fill="white"/>
    </svg>
  )
}

// Яндекс Карты логотип
function YandexIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
      {/* красный пин геолокации */}
      <circle cx="16" cy="13" r="8" fill="#FF3333"/>
      <circle cx="16" cy="13" r="4" fill="white"/>
      <path d="M16 21 L13 28 L16 25 L19 28 Z" fill="#CC0000"/>
    </svg>
  )
}

interface Props { active: string; onNav: (id: string) => void }

export default function Sidebar({ active, onNav }: Props) {
  const [collapsed, setCollapsed] = useState(false)

  return (
    <aside className={cn(
      'flex flex-col bg-white border-r border-gray-100 transition-all duration-200 shrink-0',
      collapsed ? 'w-14' : 'w-56'
    )}>
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-3 py-4 border-b border-gray-100">
        <div className="shrink-0"><SadykhanLogo size={collapsed ? 28 : 34} /></div>
        {!collapsed && (
          <div>
            <div className="text-base font-semibold leading-tight" style={{ color: '#3A9EA5' }}>
              садыхан
            </div>
            <div className="text-[10px] text-gray-400 leading-tight">Центр репутации</div>
          </div>
        )}
      </div>

      {/* Platform badges */}
      {!collapsed && (
        <div className="flex items-center gap-1.5 px-3 py-2 border-b border-gray-100">
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-gray-50 border border-gray-100">
            <TwoGisIcon size={12} />
            <span className="text-[9px] text-gray-500 font-medium">2GIS</span>
          </div>
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-gray-50 border border-gray-100">
            <YandexIcon size={12} />
            <span className="text-[9px] text-gray-500 font-medium">Яндекс</span>
          </div>
        </div>
      )}

      {/* Nav */}
      <nav className="flex-1 py-3 px-2 space-y-0.5 overflow-y-auto">
        {NAV.map((item) => {
          const Icon = item.icon
          const isActive = active === item.href.slice(1)
          return (
            <button
              key={item.href}
              onClick={() => onNav(item.href.slice(1))}
              className={cn(
                'w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-left transition-colors text-sm',
                isActive ? 'text-white' : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'
              )}
              style={isActive ? { background: '#3A9EA5' } : {}}
            >
              <Icon className="w-4 h-4 shrink-0" />
              {!collapsed && <span className="flex-1 text-sm">{item.label}</span>}
              {!collapsed && item.badge && (
                <span className="text-[10px] px-1.5 py-0.5 rounded-full text-white font-medium"
                  style={{ background: '#F5813F' }}>
                  {item.badge}
                </span>
              )}
            </button>
          )
        })}
      </nav>

      <button
        onClick={() => setCollapsed(!collapsed)}
        className="m-2 p-1.5 rounded-lg text-gray-400 hover:bg-gray-50 hover:text-gray-700 transition-colors flex items-center justify-center"
      >
        {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
      </button>
    </aside>
  )
}
